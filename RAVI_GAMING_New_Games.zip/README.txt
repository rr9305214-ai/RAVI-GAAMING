RAVI GAMING - New Games Pack

Files:
- index.html (updated home page)
- snake.html
- memory.html
- rps.html
- quiz.html

How to use:
1. Make a backup of your existing website files first.
2. Upload/replace index.html in your GitHub repository.
3. Upload the four new HTML files into the SAME folder as index.html.
4. Keep your existing carrom.html, tictactoe.html and clickgame.html files.
5. Open your GitHub Pages website and refresh.

Note: This pack adds four standalone browser games. Scores are local to the device/browser;
this is not an online multiplayer or global leaderboard system.
